# Reproducibility Report: Loss Shaping Constraints for Long-Term Forecasting

This GitHub repository contains the implementation, report, and data descriptions for reproducing the experiments of the paper:
**"Loss Shaping Constraints for Long-Term Forecasting"**

## 📚 Project Overview

This work evaluates five transformer-based forecasting models (ForecastTransformer, Autoformer, Informer, Pyraformer, iTransformer) under three types of loss constraints:
- Empirical Risk Minimization (ERM)
- Constant Constraint
- Exponential Constraint

Forecast horizons: **96 hours** and **1000 hours**  
Dataset: **ETT (Electricity Transformer Temperature)**

---

## 📂 Repository Structure

- `notebooks/Final_report_codes_96&1000_hours_Loss_shaping.ipynb` – Full experimental notebook
- `data_description.csv` – Summary of datasets used
- `load_data.py` – Script to download/load the ETTh1 dataset
- `report/EECS_6322_Reproducibility_Report.docx` – Final reproducibility write-up
- `dependencies.txt` – Required Python packages

---

## ▶️ Quick Start

```bash
# Clone repository and install dependencies
pip install -r dependencies.txt

# Load dataset
python load_data.py

# Run Jupyter notebook
jupyter notebook notebooks/Final_report_codes_96&1000_hours_Loss_shaping.ipynb
```

---

## 📈 Results Highlights

- **Exponential constraints** consistently produced the best MSE and STD values
- Visual comparisons confirm improved long-horizon stability
- Reproduction validates major claims of the original paper

---

## 🔗 Citation
If using this code, please cite the original paper and this reproducibility report.

Author: Adnan Zaidi  
ID: 222132708  
