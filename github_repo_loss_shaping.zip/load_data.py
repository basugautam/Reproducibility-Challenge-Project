import os
import pandas as pd

def load_etth1(file_path='ETTh1.csv'):
    if not os.path.exists(file_path):
        import requests
        url = 'https://raw.githubusercontent.com/zhouhaoyi/ETDataset/main/ETT-small/ETTh1.csv'
        print('Downloading ETTh1.csv...')
        with open(file_path, 'wb') as f:
            f.write(requests.get(url).content)
    return pd.read_csv(file_path)

if __name__ == '__main__':
    df = load_etth1()
    print(df.head())
